package com.zkteco.company_device_operation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyDeviceOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
