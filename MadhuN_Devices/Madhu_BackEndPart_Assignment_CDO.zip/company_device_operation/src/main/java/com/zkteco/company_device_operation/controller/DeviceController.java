package com.zkteco.company_device_operation.controller;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.company_device_operation.dto.DeviceDTO;
import com.zkteco.company_device_operation.dto.Result;
import com.zkteco.company_device_operation.entity.Device;
import com.zkteco.company_device_operation.service.DeviceService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping(value = "device")
public class DeviceController {

	@Autowired
	private DeviceService service;
	@Autowired
	private ModelMapper modelMapper;

	private final Logger logger = LoggerFactory.getLogger(DeviceController.class);

	@PostMapping("/")
	public Result saveDevice(@Valid @RequestBody DeviceDTO deviceDto, HttpServletRequest request) {
		// convert DTO to entity
		logger.info("Inside save Device Method");
		Device device = this.modelMapper.map(deviceDto, Device.class);
		return service.saveDevice(device, request);
	}

	@GetMapping("list/zkteco")
	public Result getAllDevicesZk() {
		logger.info("Inside getAllDevices of DeviceController");
		return service.getAllDevices();
	}

	@GetMapping("list/amazon")
	public Result getAllDevicesAmazon() {
		logger.info("Inside getAllDevices of DeviceController");
		return service.getAllDevices();
	}

	@GetMapping("/{id}")
	public Result getDeviceById(@PathVariable("id") Long id, HttpServletRequest request) {
		logger.info("Inside getDeviceById of DeviceController");
		return service.getDeviceById(id, request);
	}

	@DeleteMapping("/{id}")
	public Result deleteDeviceById(@PathVariable("id") Long id, HttpServletRequest request) {
		logger.info("Inside deleteDeviceById of DeviceController");
		return service.deleteDeviceById(id, request);
	}

	@PutMapping("/update/{id}")
	public Result updateDeviceById(@RequestBody DeviceDTO deviceDto, @PathVariable("id") Long id,
			HttpServletRequest request) {
		logger.info("Inside updateDeviceById of DeviceController");
		Device device = this.modelMapper.map(deviceDto, Device.class);
		return service.updateDeviceById(device, id, request);
	}
}
