package com.zkteco.company_device_operation.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceDTO {

	private Long id;
	private String name;
	private String type;
	private String description;
	private String price;
	private String photo;
	private String createDate;
	private String updatedDate;

}
