package com.zkteco.company_device_operation.service;

import org.springframework.stereotype.Service;

import com.zkteco.company_device_operation.dto.Result;
import com.zkteco.company_device_operation.entity.Device;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Service
public interface DeviceService {

	Result saveDevice(@Valid Device device, HttpServletRequest request);

	Result getDeviceById(Long id, HttpServletRequest request);

	Result getAllDevices();

	Result deleteDeviceById(Long id, HttpServletRequest request);

	Result updateDeviceById(Device device, Long id, HttpServletRequest request);

}
