package com.zkteco.company_device_operation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zkteco.company_device_operation.entity.Device;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long> {

}
