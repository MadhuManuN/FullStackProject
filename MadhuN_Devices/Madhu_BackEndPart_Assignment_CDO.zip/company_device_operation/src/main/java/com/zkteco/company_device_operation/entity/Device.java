package com.zkteco.company_device_operation.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Device_Data")
public class Device {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Device_id")
	private Long id;

	@Column(name = "Device_Name")
	private String name;

	@Column(name = "Device_Type")
	private String type;

	@Column(name = "Description")
	@Lob
	private String description;

	@Column(name = "Device_Price")
	private String price;

	@Column(name = "Device_Photo")
	@Lob
	private String photo;

	@Column(name = "Created_Date")
	private String createDate;

	@Column(name = "Updated_Date")
	private String updatedDate;
}
