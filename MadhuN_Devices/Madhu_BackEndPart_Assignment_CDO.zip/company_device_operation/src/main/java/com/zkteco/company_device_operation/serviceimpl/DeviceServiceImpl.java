package com.zkteco.company_device_operation.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.zkteco.company_device_operation.config.MyLocaleResolver;
import com.zkteco.company_device_operation.dto.DeviceDTO;
import com.zkteco.company_device_operation.dto.Result;
import com.zkteco.company_device_operation.entity.Device;
import com.zkteco.company_device_operation.repository.DeviceRepository;
import com.zkteco.company_device_operation.service.DeviceService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Service
public class DeviceServiceImpl implements DeviceService {

	@Autowired
	private DeviceRepository repository;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private MessageSource messageSource;

	@Autowired
	private MyLocaleResolver localeResolver;

	private final Logger logger = LoggerFactory.getLogger(DeviceServiceImpl.class);
	Date date = new Date();
	SimpleDateFormat dateForm = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

	private Result validation(@Valid Device device, HttpServletRequest request) {
		logger.info("Inside validation method of DeviceServiceImpl");
		String errorId = messageSource.getMessage("CDOE0001", null, localeResolver.resolveLocale(request));
		String errorCode = messageSource.getMessage("CDOE0010", null, localeResolver.resolveLocale(request));
		String successCode = messageSource.getMessage("CDOI0005", null, localeResolver.resolveLocale(request));
		String successSave = messageSource.getMessage("CDOI0002", null, localeResolver.resolveLocale(request));
		String errorData = messageSource.getMessage("CDOE0002", null, localeResolver.resolveLocale(request));

		Optional<Device> deviceDbData = repository.findById(device.getId());
		Device deviceResponse;

		if (!(device.getId() != 0)) {
			return new Result(errorCode, errorId, "[]");
		}
		String str1 = Long.toString(device.getId());
		if(!(str1.matches("^\\d+$"))) {
			return new Result(errorCode, "Id should be only Number", "[]");
		}
	    
		Result resultMand = validationMandatory(device, request);
		if (resultMand != null)
			return resultMand;

		if (deviceDbData.isEmpty()) {
			device.setCreateDate(dateForm.format(date));
			device.setUpdatedDate(dateForm.format(date));
			deviceResponse = repository.save(device);
			DeviceDTO deviceDTO = this.modelMapper.map(deviceResponse, DeviceDTO.class);
			return new Result(successCode, successSave, deviceDTO);
		}
		return new Result(errorCode, errorData, "");
	}

	private Result validationMandatory(@Valid Device device, HttpServletRequest request) {
		logger.info("Inside validationMandatory method of DeviceServiceImpl");
		String errorCode = messageSource.getMessage("CDOE0010", null, localeResolver.resolveLocale(request));
		String errorName1 = messageSource.getMessage("CDOE0003", null, localeResolver.resolveLocale(request));
		String errorName2 = messageSource.getMessage("CDOE0004", null, localeResolver.resolveLocale(request));
		String errorType1 = messageSource.getMessage("CDOE0005", null, localeResolver.resolveLocale(request));
		String errorType2 = messageSource.getMessage("CDOE0006", null, localeResolver.resolveLocale(request));
		String errorPrice = messageSource.getMessage("CDOE0011", null, localeResolver.resolveLocale(request));
		String errorDesc = messageSource.getMessage("CDOE0012", null, localeResolver.resolveLocale(request));
		String errorPhoto = messageSource.getMessage("CDOE0013", null, localeResolver.resolveLocale(request));
		String name = device.getName();
		String type = device.getType();
		String price = device.getPrice();
		String description=device.getDescription();
		String photo=device.getPhoto();
		if (!name.isEmpty()) {
			if (name.length() >= 36) {
				return new Result(errorCode, errorName1, "[]");
			}
		} else {
			return new Result(errorCode, errorName2, "[]");
		}
		if (!type.isEmpty()) {
			if (type.length() >= 200) {
				return new Result(errorCode, errorType1, "[]");
			}
		} else {
			return new Result(errorCode, errorType2, "[]");
		}
		if (price.isEmpty()) {
			return new Result(errorCode, errorPrice, "[]");
		}
		if(description.isEmpty()) return new Result(errorCode, errorDesc, "[]");
		if(photo.isEmpty()) return new Result(errorCode, errorPhoto, "[]");
		return null;
	}

	@Override
	public Result saveDevice(@Valid Device device, HttpServletRequest request) {
		String errorCode = messageSource.getMessage("CDOE0010", null, localeResolver.resolveLocale(request));
		String errorRequest = messageSource.getMessage("CDOE0008", null, localeResolver.resolveLocale(request));

		logger.info("Inside saveDevice of DeviceServiceImpl");
		if (device != null) {
			return validation(device, request);
		}
		return new Result(errorCode, errorRequest, "");
	}

	@Override
	public Result getDeviceById(Long id, HttpServletRequest request) {

		String errorCode = messageSource.getMessage("CDOE0010", null, localeResolver.resolveLocale(request));
		String successCode = messageSource.getMessage("CDOI0005", null, localeResolver.resolveLocale(request));
		String errorData = messageSource.getMessage("CDOE0009", null, localeResolver.resolveLocale(request));
		String successDataFetch = messageSource.getMessage("CDOI0003", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Optional<Device> device = repository.findById(id);
		if (!device.isEmpty()) {
			DeviceDTO deviceDTO = this.modelMapper.map(device.get(), DeviceDTO.class);
			result.setCode(successCode);
			result.setData(deviceDTO);
			result.setMessage(successDataFetch);
		} else {
			result.setCode(errorCode);
			result.setMessage(errorData);
		}
		return result;
	}

	@Override
	public Result getAllDevices() {
		logger.info("Inside getAllDevices of DeviceServiceImpl");
		return new Result("CMSI100", "Successfully Fetched", repository.findAll());
	}

	@Override
	public Result deleteDeviceById(Long id, HttpServletRequest request) {
		String errorCode = messageSource.getMessage("CDOE0010", null, localeResolver.resolveLocale(request));
		String successCode = messageSource.getMessage("CDOI0005", null, localeResolver.resolveLocale(request));
		String errorData = messageSource.getMessage("CDOE0009", null, localeResolver.resolveLocale(request));
		String successData = messageSource.getMessage("CDOI0001", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Optional<Device> device = repository.findById(id);
		if (!device.isEmpty()) {
			result.setCode(successCode);
			result.setMessage(successData);
			result.setData("[]");
			repository.deleteById(id);
		} else {
			result.setCode(errorCode);
			result.setMessage(errorData);
			result.setData("[]");
		}
		return result;
	}

	@Override
	public Result updateDeviceById(Device device, Long id, HttpServletRequest request) {
		String errorCode = messageSource.getMessage("CDOE0010", null, localeResolver.resolveLocale(request));
		String successCode = messageSource.getMessage("CDOI0005", null, localeResolver.resolveLocale(request));
		String errorData = messageSource.getMessage("CDOE0009", null, localeResolver.resolveLocale(request));
		String successDataUpdate = messageSource.getMessage("CDOI0004", null, localeResolver.resolveLocale(request));
		Result result;
		Device devicedb = repository.findById(id).get();

		if (devicedb == null) {
			return new Result(errorCode, errorData, "");
		}

		if (Objects.nonNull(device.getName()) && !"".equalsIgnoreCase(device.getName())) // if null and empty data then
																							// skip that data

		{
			devicedb.setName(device.getName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(device.getType()) && !"".equalsIgnoreCase(device.getType())) // if null and empty data then
																							// skip that data

		{
			devicedb.setType(device.getType());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(device.getDescription()) && !"".equalsIgnoreCase(device.getDescription())) // if null and
																										// empty data
																										// then skip
																										// that data
		{
			devicedb.setDescription(device.getDescription());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(device.getPrice()) && !"".equalsIgnoreCase(device.getPrice())) // if null and empty data
																							// then skip that data
		{
			devicedb.setPrice(device.getPrice());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(device.getPhoto()) && !"".equalsIgnoreCase(device.getPhoto())) // if null and empty data
																							// then skip that data
		{
			devicedb.setPhoto(device.getPhoto());// if non null and not blank then we are setting the data
		}
		devicedb.setCreateDate(dateForm.format(date));
		devicedb.setUpdatedDate(dateForm.format(date));
		Result resultMand = validationMandatory(device, request);
		if (resultMand != null) {
			return resultMand;
		} else {
			repository.save(devicedb);
			DeviceDTO deviceDTO = this.modelMapper.map(devicedb, DeviceDTO.class);
			result = new Result(successCode, successDataUpdate, deviceDTO);
		}
		return result;
	}

}
